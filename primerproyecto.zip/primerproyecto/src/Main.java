//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args){
        System.out.println("Bienvenido(a) a Screen Match");
        System.out.println("Película : Matrix");

         int fechaDeLanzamiento = 1999;
         boolean incluidoEnElPlan = true;
         double calificacion = 8.2;
         double media = (8.2 + 6.0 + 9.0) / 3;

         System.out.println(media);

         String sinopsis = """
                 Matrix es una paradoja
                 La mejor película del fin del milenio
                 Fue lanzada en:
                 """ + fechaDeLanzamiento;
        System.out.println(sinopsis);

        int clasificacion = (int) (media / 2);
        System.out.println(clasificacion);

        double gradosCelcius = 14.5;

        int gradosFahrenheit = (int)((gradosCelcius * 1.8)+32);

        System.out.println(gradosFahrenheit);

    }
}

