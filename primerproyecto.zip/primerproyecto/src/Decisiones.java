public class Decisiones {
    public  static void  main(String[] args){
        int fechaDeLanzamiento = 1999;
        boolean incluidoEnElPlan = true;
        double calificacion = 8.2;
        String tipoDePlan = "Plus";

        if(fechaDeLanzamiento >= 2022){
            System.out.println("Películas más populares");
        }else{
            System.out.println("Películas de culto");
        }
        if(incluidoEnElPlan && tipoDePlan.equals("Plus")){
            System.out.println("Disfrute de su película");
        }else{
            System.out.println("Actualice su plan a Plus");
        }
    }
}
