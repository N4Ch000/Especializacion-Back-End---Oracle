import java.util.Random;
import java.util.Scanner;

public class Adivinacion {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int numeroSecreto = new Random().nextInt(100);
        int numeroUsuario = 0;
        int intentos = 0;

        while(intentos < 5){
            System.out.println("Elije un número del 0 al 100");
            numeroUsuario = teclado.nextInt();
            intentos++;
            if(numeroUsuario == numeroSecreto){
                System.out.println("Acertaste al número secreto: "+ numeroSecreto);
                break;
            }else if(numeroUsuario < numeroSecreto){
                System.out.println("El número que escribiste es menor al número secreto");
            }else{
                System.out.println("El número que escribiste es mayor al número secreto");
            }
        }
        if (intentos == 5){
            System.out.println("No acertaste en los "+ intentos + " intentos designados");
        }
    }
}